// login.js - Only for login.html

// Shared data initialization
let users = JSON.parse(localStorage.getItem('users')) || [
    {
        username: 'ahmet',
        password: '12345',
        registrationDate: new Date().toLocaleDateString('tr-TR'),
        reservations: [],
        reviews: []
    }
];
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;

// Shared functions
function saveToLocalStorage() {
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
}

// Login page specific functions
function setupLoginPage() {
    // Redirect if already logged in
    if (currentUser) {
        window.location.replace('profile.html');
        return;
    }

    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const username = document.getElementById('login-username').value.trim();
            const password = document.getElementById('login-password').value.trim();
            const loginBtn = document.querySelector('#login-form button');

            // Disable form during processing
            loginBtn.disabled = true;
            loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Giriş Yapılıyor';

            // Simulate network delay
            await new Promise(resolve => setTimeout(resolve, 800));

            const user = users.find(user => 
                user.username === username && 
                user.password === password
            );
            
            if (user) {
                currentUser = user;
                saveToLocalStorage();
                
                loginBtn.innerHTML = '<i class="fas fa-check"></i> Giriş Başarılı';
                loginBtn.classList.add('success');
                
                setTimeout(() => {
                    window.location.replace('profile.html');
                }, 1000);
            } else {
                loginBtn.disabled = false;
                loginBtn.innerHTML = 'Giriş Yap';
                loginBtn.classList.remove('success');
                
                loginForm.classList.add('shake');
                setTimeout(() => {
                    loginForm.classList.remove('shake');
                }, 500);
                
                document.getElementById('login-password').value = '';
                alert('Kullanıcı adı veya şifre yanlış!');
            }
        });
    }

    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('signup-username').value.trim();
            const password = document.getElementById('signup-password').value.trim();
            const signupBtn = document.querySelector('#signup-form button');

            // Disable form during processing
            signupBtn.disabled = true;
            signupBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Kayıt Yapılıyor';

            // Simulate network delay
            await new Promise(resolve => setTimeout(resolve, 800));

            if (users.some(user => user.username === username)) {
                signupBtn.disabled = false;
                signupBtn.innerHTML = 'Kayıt Ol';
                alert('Bu kullanıcı adı zaten alınmış!');
                return;
            }

            const newUser = {
                username,
                password,
                registrationDate: new Date().toLocaleDateString('tr-TR'),
                reservations: [],
                reviews: []
            };

            users.push(newUser);
            saveToLocalStorage();

            signupBtn.innerHTML = '<i class="fas fa-check"></i> Kayıt Başarılı';
            signupBtn.classList.add('success');

            setTimeout(() => {
                document.getElementById('chk').checked = true;
                document.getElementById('login-username').value = username;
                signupForm.reset();
                signupBtn.disabled = false;
                signupBtn.innerHTML = 'Kayıt Ol';
                signupBtn.classList.remove('success');
                alert('Kayıt başarılı! Giriş yapabilirsiniz.');
            }, 1000);
        });
    }
}

// Initialize login page
document.addEventListener('DOMContentLoaded', setupLoginPage);