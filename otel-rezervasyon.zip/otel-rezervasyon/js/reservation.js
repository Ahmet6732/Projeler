// let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;

function updateNavbar() {
    const loginLink = document.querySelector('.navbar-menu .login-btn');
    if (!loginLink) {
        console.warn('Uyarı: login-btn bulunamadı');
        return;
    }

    if (currentUser) {
        loginLink.innerHTML = '<i class="fas fa-sign-out-alt"></i> Çıkış Yap';
        loginLink.href = '#';
        loginLink.onclick = handleLogout;
    } else {
        loginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i> Giriş Yap';
        loginLink.href = 'login.html';
        loginLink.onclick = null;
    }
}

function handleLogout(e) {
    e.preventDefault();
    currentUser = null;
    localStorage.removeItem('currentUser');
    showToast('Başarıyla çıkış yapıldı', 'success');
    setTimeout(() => window.location.href = 'index.html', 1500);
}

function showToast(message, type = 'info') {
    const existingToasts = document.querySelectorAll('.toast');
    existingToasts.forEach(toast => toast.remove());
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    let iconClass;
    switch(type) {
        case 'success':
            iconClass = 'fas fa-check-circle';
            break;
        case 'error':
            iconClass = 'fas fa-exclamation-circle';
            break;
        default:
            iconClass = 'fas fa-info-circle';
    }
    
    toast.innerHTML = `<i class="${iconClass}"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 5000);
    }, 100);
}

function calculateNights(checkIn, checkOut) {
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round(Math.abs((new Date(checkOut) - new Date(checkIn)) / oneDay));
}

function updateLocalStorageAndUser() {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userIndex = users.findIndex(u => u.username === currentUser.username);
    
    if (userIndex !== -1) {
        users[userIndex] = currentUser;
    } else {
        users.push(currentUser);
    }
    
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
}

function setupReservationPage() {
    if (!currentUser) {
        showToast('Rezervasyon yapabilmek için lütfen giriş yapın!', 'error');
        setTimeout(() => window.location.href = 'login.html', 1500);
        return;
    }

    const hotelImage = document.getElementById('hotel-image');
    const hotelName = document.getElementById('hotel-name');
    const hotelRating = document.getElementById('hotel-rating');
    const hotelLocation = document.getElementById('hotel-location');
    const hotelAmenities = document.getElementById('hotel-amenities');
    const roomType = document.getElementById('room-type');
    const checkInInput = document.getElementById('check-in');
    const checkOutInput = document.getElementById('check-out');
    const nights = document.getElementById('nights');
    const roomPrice = document.getElementById('room-price');
    const taxes = document.getElementById('taxes');
    const totalPrice = document.getElementById('total-price');
    const guestForm = document.getElementById('guest-form');
    const payBtn = document.getElementById('pay-btn');
    const termsCheckbox = document.getElementById('terms');
    const errorMessage = document.getElementById('error-message');

    if (!payBtn || !termsCheckbox || !guestForm || !hotelName || !checkInInput || !checkOutInput) {
        showToast('Sayfa yüklenirken hata oluştu!', 'error');
        console.error('Missing elements:', { payBtn, termsCheckbox, guestForm, hotelName, checkInInput, checkOutInput });
        return;
    }

    const urlParams = new URLSearchParams(window.location.search);
    const hotelId = parseInt(urlParams.get('hotel'));
    const roomTypeParam = decodeURIComponent(urlParams.get('room') || '');
    const checkIn = urlParams.get('checkin');
    const checkOut = urlParams.get('checkout');

    if (!checkIn || !checkOut || !hotelId || !roomTypeParam) {
        showToast('Rezervasyon için gerekli bilgiler eksik!', 'error');
        console.error('Missing URL parameters:', { hotelId, roomTypeParam, checkIn, checkOut });
        setTimeout(() => window.location.href = 'hotels.html', 1500);
        return;
    }

    const hotels = [
        { id: 1, name: "Grand Palace - İstanbul", city: "İstanbul", Rating: 4.8, Image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg", Rooms: [{ Type: "Standart Oda", Price: 1200, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Klima" }, { Feature: "Minibar" }] }, { Type: "Deluxe Süit", Price: 2000, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Jakuzi" }, { Feature: "Manzara" }] }] },
        { id: 2, name: "Sea View Resort - Antalya", city: "Antalya", Rating: 4.5, Image: "https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg", Rooms: [{ Type: "Standart Deniz Manzaralı", Price: 1500, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Balkon" }] }] },
        { id: 4, name: "City Comfort - Ankara", city: "Ankara", Rating: 4.0, Image: "https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg", Rooms: [{ Type: "Tek Kişilik Oda", Price: 800, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Çalışma Masası" }] }] },
        { id: 5, name: "Luxor Spa & Resort - Bodrum", city: "Muğla", Rating: 4.7, Image: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg", Rooms: [{ Type: "Suit Odası", Price: 1400, Features: [{ Feature: "Özel Plaj" }, { Feature: "Jakuzi" }] }] },
        { id: 6, name: "Cappadocia Cave Hotel - Nevşehir", city: "Nevşehir", Rating: 4.9, Image: "https://images.pexels.com/photos/532826/pexels-photo-532826.jpeg", Rooms: [{ Type: "Mağara Süiti", Price: 1800, Features: [{ Feature: "Doğal Taş Duş" }, { Feature: "Balon Turu İndirimi" }] }] },
        { id: 3, name: "Pine Forest Hotel - Bursa", city: "Bursa", Rating: 4.3, Image: "https://images.pexels.com/photos/2581922/pexels-photo-2581922.jpeg", Rooms: [{ Type: "Orman Manzaralı Oda", Price: 850, Features: [{ Feature: "Şömine" }, { Feature: "Doğa Yürüyüş Parkuru" }] }] },
        { id: 9, name: "Business Tower - İzmir", city: "İzmir", Rating: 4.5, Image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg", Rooms: [{ Type: "Executive Oda", Price: 1400, Features: [{ Feature: "Geniş Balkon" }, { Feature: "Ücretsiz WiFi" }] }] },
        { id: 7, name: "Thermal Palace - Afyon", city: "Afyon", Rating: 4.4, Image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg", Rooms: [{ Type: "Termal Suit", Price: 950, Features: [{ Feature: "Özel Termal Küvet" }, { Feature: "Spa Girişi" }] }] },
        { id: 8, name: "Ski Lodge - Kayseri", city: "Kayseri", Rating: 4.6, Image: "https://images.pexels.com/photos/1365425/pexels-photo-1365425.jpeg", Rooms: [{ Type: "Kayakçı Odası", Price: 1300, Features: [{ Feature: "Kayak Dolabı" }, { Feature: "Şömine" }] }] }
    ];

    let selectedHotel = null;
    let selectedRoom = null;

    const loadReservationDetails = () => {
        try {
            selectedHotel = hotels.find(h => h.id === hotelId);
            if (!selectedHotel) {
                hotelName.textContent = 'Hata: Otel bulunamadı.';
                payBtn.disabled = true;
                errorMessage.textContent = 'Lütfen otel seçimi yaparak tekrar deneyin.';
                errorMessage.style.display = 'block';
                console.error('Hotel not found:', hotelId);
                setTimeout(() => window.location.href = 'hotels.html', 3000);
                return;
            }

            selectedRoom = selectedHotel.Rooms.find(r => r.Type === roomTypeParam);
            if (!selectedRoom) {
                hotelName.textContent = 'Hata: Seçilen oda bulunamadı.';
                payBtn.disabled = true;
                errorMessage.textContent = 'Lütfen geçerli bir oda seçimi yapın.';
                errorMessage.style.display = 'block';
                console.error('Room not found:', roomTypeParam);
                setTimeout(() => window.location.href = 'hotels.html', 3000);
                return;
            }

            hotelImage.src = selectedHotel.Image;
            hotelImage.alt = selectedHotel.name;
            hotelName.textContent = `${selectedHotel.name} - ${roomTypeParam}`;
            hotelRating.innerHTML = `${'★'.repeat(Math.floor(selectedHotel.Rating))}${'☆'.repeat(5 - Math.floor(selectedHotel.Rating))} <span>${selectedHotel.Rating} (${Math.floor(Math.random() * 200) + 100} Değerlendirme)</span>`;
            hotelLocation.innerHTML = `<i class="fas fa-map-marker-alt"></i> ${selectedHotel.city}`;
            hotelAmenities.innerHTML = selectedRoom.Features.map(f => `
                <span>
                    <i class="${f.Feature.includes('WiFi') ? 'fa-solid fa-wifi' : 
                               f.Feature.includes('Havuz') ? 'fa-solid fa-swimming-pool' : 
                               f.Feature.includes('Spa') ? 'fa-solid fa-spa' : 
                               f.Feature.includes('Restoran') ? 'fa-solid fa-utensils' : 
                               f.Feature.includes('Jakuzi') ? 'fa-solid fa-hot-tub' : 
                               f.Feature.includes('Balkon') ? 'fa-solid fa-door-open' : 
                               f.Feature.includes('Minibar') ? 'fa-solid fa-cocktail' : 
                               f.Feature.includes('Klima') ? 'fa-solid fa-fan' : 'fa-solid fa-check'}"></i>
                    ${f.Feature}
                </span>
            `).join('');
            if (roomType) roomType.textContent = roomTypeParam;
            checkInInput.value = checkIn;
            checkOutInput.value = checkOut;

            const updatePrice = () => {
    const checkInVal = checkInInput.value;
    const checkOutVal = checkOutInput.value;
    if (!checkInVal || !checkOutVal) {
        nights.textContent = 'Tarih seçiniz';
        payBtn.disabled = true;
        return;
    }

    const nightCount = calculateNights(checkInVal, checkOutVal);
    nights.textContent = `${nightCount} Gece`;

    const roomCost = selectedRoom.Price * nightCount;
    const tax = roomCost * 0.1;
    const total = roomCost + tax;

    roomPrice.innerHTML = `<span>${nightCount} Gece x ${selectedRoom.Price} TL</span><span>${roomCost} TL</span>`;
    taxes.textContent = `${tax.toFixed(2)} TL`;
    totalPrice.textContent = `${total.toFixed(2)} TL`;
    payBtn.innerHTML = `<i class="fas fa-lock"></i> Ödeme Yap`;
    payBtn.disabled = !termsCheckbox.checked;
};

updatePrice();

if (currentUser) {
    document.getElementById('name').value = currentUser.fullName || '';
    document.getElementById('phone').value = currentUser.phone || '';
}

termsCheckbox.addEventListener('change', () => {
    payBtn.disabled = !termsCheckbox.checked;
});

payBtn.disabled = !termsCheckbox.checked;
} catch (error) {
    hotelName.textContent = 'Hata: Otel bilgileri yüklenemedi.';
    payBtn.disabled = true;
    errorMessage.textContent = 'Otel bilgileri yüklenirken hata oluştu.';
    errorMessage.style.display = 'block';
    console.error('Error loading reservation details:', error);
}
};

const validateForm = () => {
    const name = document.getElementById('name').value.trim();
    const phone = document.getElementById('phone').value.trim();
    const cardNumber = document.getElementById('card-number').value.trim();
    const terms = document.getElementById('terms').checked;

    if (!checkIn || !checkOut) {
        showError('Giriş ve çıkış tarihleri gerekli!');
        return false;
    }
    const today = new Date().toISOString().split('T')[0];
    if (checkIn < today) {
        showError('Giriş tarihi geçmişte olamaz!');
        return false;
    }
    if (new Date(checkOut) <= new Date(checkIn)) {
        showError('Çıkış tarihi giriş tarihinden sonra olmalı!');
        return false;
    }
    if (!name || name.length < 3) {
        showError('Ad Soyad en az 3 karakter olmalı.');
        return false;
    }
    if (!phone || !/^0\d{10}$/.test(phone.replace(/\s/g, ''))) {
        showError('Telefon numarası 0 ile başlamalı ve 11 haneli olmalı (örn: 05551234567).');
        return false;
    }
    if (!cardNumber || !/^\d{16}$/.test(cardNumber.replace(/\s/g, ''))) {
        showError('Geçerli bir 16 haneli kart numarası girin.');
        return false;
    }
    if (!terms) {
        showError('Kullanım koşullarını kabul etmelisiniz.');
        return false;
    }
    return true;
};

const showError = (message) => {
    errorMessage.textContent = message;
    errorMessage.style.display = 'block';
    setTimeout(() => errorMessage.style.display = 'none', 3000);
};

guestForm.addEventListener('submit', (e) => {
    e.preventDefault();
    errorMessage.style.display = 'none';

    if (!validateForm()) {
        return;
    }

    payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ödeme İşleniyor...';
    payBtn.disabled = true;
    payBtn.classList.add('processing');

    try {
        const nightCount = calculateNights(checkIn, checkOut);
        const total = (selectedRoom.Price * nightCount * 1.1).toFixed(2);

        const reservation = {
            id: 'RES-' + Date.now(),
            hotel: selectedHotel.name,
            roomType: roomTypeParam,
            checkIn,
            checkOut,
            nights: nightCount,
            totalPrice: total,
            status: 'confirmed',
            guestInfo: {
                fullName: document.getElementById('name').value,
                phone: document.getElementById('phone').value
            }
        };

        if (!currentUser.reservations) currentUser.reservations = [];
        currentUser.reservations.push(reservation);
        updateLocalStorageAndUser();

        showToast('Rezervasyonunuz alınmıştır!', 'success');
        setTimeout(() => {
            window.location.href = 'profile.html?tab=reservations';
        }, 1500);
    } catch (error) {
        showToast(`Rezervasyon sırasında hata oluştu: ${error.message}`, 'error');
        payBtn.innerHTML = `<i class="fas fa-lock"></i> Ödeme Yap`;
        payBtn.disabled = !termsCheckbox.checked;
        payBtn.classList.remove('processing');
    }
});

document.querySelector('.mobile-menu-btn').addEventListener('click', () => {
    const menu = document.querySelector('.navbar-menu');
    const icon = document.querySelector('.mobile-menu-btn i');
    const isActive = menu.classList.toggle('active');
    icon.className = isActive ? 'fas fa-times' : 'fas fa-bars';
});

loadReservationDetails();
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('reservation.js loaded');
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.has('reservation_success')) {
        showToast('Rezervasyonunuz başarıyla oluşturuldu!', 'success');
    }
    updateNavbar();
    setupReservationPage();
});

let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 3000);
    }, 100);
}

function loadReservations() {
    const reservationsList = document.getElementById('reservations-list');
    if (!reservationsList) {
        console.error('reservations-list element not found');
        return;
    }

    reservationsList.innerHTML = '<h3>Rezervasyonlarım</h3>';
    if (!currentUser?.reservations || currentUser.reservations.length === 0) {
        reservationsList.innerHTML += '<p>Henüz rezervasyonunuz yok.</p>';
        return;
    }

    currentUser.reservations.forEach(res => {
        const resItem = document.createElement('div');
        resItem.className = 'reservation-item';
        resItem.innerHTML = `
            <h4>${res.hotel}</h4>
            <p><strong>Rezervasyon ID:</strong> ${res.id}</p>
            <p><strong>Oda Tipi:</strong> ${res.roomType}</p>
            <p><strong>Giriş:</strong> ${res.checkIn} | <strong>Çıkış:</strong> ${res.checkOut}</p>
            <p><strong>Gece:</strong> ${res.nights} | <strong>Fiyat:</strong> ${res.totalPrice} TL</p>
            <p><strong>Ad Soyad:</strong> ${res.guestInfo.fullName}</p>
            <p><strong>Telefon:</strong> ${res.guestInfo.phone}</p>
            ${res.notes ? `<p><strong>Özel İstekler:</strong> ${res.notes}</p>` : ''}
            <p><strong>Durum:</strong> Onaylandı</p>
        `;
        reservationsList.appendChild(resItem);
    });
    console.log('Reservations loaded:', currentUser.reservations);
}
payBtn.addEventListener('click', (e) => {
    e.preventDefault();
    errorMessage.style.display = 'none';

    if (!validateForm()) {
        return;
    }

    payBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Ödeme İşleniyor...';
    payBtn.disabled = true;
    payBtn.classList.add('processing');

    try {
        const nightCount = calculateNights(checkIn, checkOut);
        const total = (selectedRoom.Price * nightCount * 1.1).toFixed(2);

        const reservation = {
            id: 'RES-' + Date.now(),
            hotel: selectedHotel.name,
            roomType: roomTypeParam,
            checkIn,
            checkOut,
            nights: nightCount,
            totalPrice: total,
            status: 'confirmed',
            guestInfo: {
                fullName: document.getElementById('name').value,
                phone: document.getElementById('phone').value
            },
            hotelId: hotelId,
            roomImage: selectedHotel.Image
        };

        if (!currentUser.reservations) currentUser.reservations = [];
        currentUser.reservations.push(reservation);
        
        // Update user data in localStorage
        const users = JSON.parse(localStorage.getItem('users')) || [];
        const userIndex = users.findIndex(u => u.username === currentUser.username);
        if (userIndex !== -1) {
            users[userIndex] = currentUser;
            localStorage.setItem('users', JSON.stringify(users));
        }
        localStorage.setItem('currentUser', JSON.stringify(currentUser));

        showToast('Rezervasyonunuz başarıyla oluşturuldu!', 'success');
        setTimeout(() => {
            window.location.href = 'profile.html?tab=reservations';
        }, 1500);
    } catch (error) {
        showToast(`Rezervasyon sırasında hata oluştu: ${error.message}`, 'error');
        payBtn.innerHTML = '<i class="fas fa-lock"></i> Ödeme Yap';
        payBtn.disabled = !termsCheckbox.checked;
        payBtn.classList.remove('processing');
    }
});
document.addEventListener('DOMContentLoaded', function() {
    console.log('profile.js loaded');
    if (!currentUser) {
        showToast('Lütfen giriş yapın!', 'error');
        setTimeout(() => window.location.href = 'login.html', 1500);
        return;
    }
    loadReservations();
});