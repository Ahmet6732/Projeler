function showToast(message, type = 'info') {
    // Remove existing toasts to prevent overlap
    const existingToasts = document.querySelectorAll('.toast');
    existingToasts.forEach(toast => toast.remove());

    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    
    let iconClass;
    switch(type) {
        case 'success':
            iconClass = 'fas fa-check-circle';
            break;
        case 'error':
            iconClass = 'fas fa-exclamation-circle';
            break;
        default:
            iconClass = 'fas fa-info-circle';
    }
    
    toast.innerHTML = `
        <div class="toast-icon">
            <i class="${iconClass}"></i>
        </div>
        <div class="toast-message">${message}</div>
    `;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 5000); // Keep 5-second duration as in original
    }, 100);
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('admin.js loaded');
    const loginForm = document.getElementById('admin-login-form');
    if (!loginForm) {
        console.error('Admin login form not found');
        return;
    }

    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('admin-username').value.trim();
        const password = document.getElementById('admin-password').value.trim();
        const submitButton = loginForm.querySelector('button');

        if (username === 'Ahmet' && password === '3234') {
            submitButton.classList.add('success');
            submitButton.textContent = 'Giriş Başarılı!';
            showToast('Admin girişi başarılı!', 'success');
            setTimeout(() => {
                window.location.href = 'adminpanel.html';
            }, 1500);
        } else {
            showToast('Kullanıcı adı veya şifre yanlış!', 'error');
            submitButton.textContent = 'Giriş';
            submitButton.classList.remove('success');
        }
    });
});