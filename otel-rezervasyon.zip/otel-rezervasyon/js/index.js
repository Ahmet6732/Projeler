// index.js - Only for index.html

// Uygulama başlangıcında veri yapılarını kontrol et
if (!localStorage.getItem('users')) {
    localStorage.setItem('users', JSON.stringify([]));
}
if (!localStorage.getItem('currentUser')) {
    localStorage.setItem('currentUser', JSON.stringify(null));
}

// Kullanıcı ve oturum verileri
let users = JSON.parse(localStorage.getItem('users'));
let currentUser = JSON.parse(localStorage.getItem('currentUser'));

// LocalStorage'a kaydetme fonksiyonu
function saveToLocalStorage() {
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
}

// Navbar menüsünü güncelle
function updateNavbar() {
    const loginLink = document.querySelector('.navbar-menu .login-btn');
    if (!loginLink) return;

    if (currentUser) {
        loginLink.innerHTML = '<i class="fas fa-sign-out-alt"></i> Çıkış Yap';
        loginLink.href = '#';
        loginLink.onclick = handleLogout;
    } else {
        loginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i> Giriş Yap';
        loginLink.href = 'login.html';
        loginLink.onclick = null;
    }
}

// Çıkış yapma işlemi
function handleLogout(e) {
    e.preventDefault();
    currentUser = null;
    saveToLocalStorage();
    updateNavbar();
    showToast('Başarıyla çıkış yapıldı', 'success');
}

// Toast bildirimi
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
}

// Mobil menü butonunu aktif et
function setupMobileMenu() {
    const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
    const navbarMenu = document.querySelector('.navbar-menu');
    
    if (mobileMenuBtn && navbarMenu) {
        mobileMenuBtn.addEventListener('click', () => {
            const isActive = navbarMenu.classList.toggle('active');
            mobileMenuBtn.setAttribute('aria-expanded', isActive);
            mobileMenuBtn.innerHTML = isActive 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
    }
}

// Otel verisi (API yerine statik)
const hotels = [
    {
            HotelID: 1,
            Name: "Grand Palace - İstanbul",
            Location: "İstanbul",
            Rating: 4.8,
            Price: 1200,
            Image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg",
            Description: "İstanbul'un tarihi yarımadasında muhteşem bir konumda yer alan Grand Palace, lüks ve konforu benzersiz bir şekilde bir araya getiriyor. Topkapı Sarayı'na ve Ayasofya'ya sadece 5 dakika yürüme mesafesindeki otelimiz, şehrin en önemli tarihi mekanlarına yakınlığıyla misafirlerine eşsiz bir deneyim sunuyor.",
            Rooms: [
                {
                    Type: "Standart Oda",
                    Capacity: 2,
                    Price: 1200,
                    Image: "https://images.pexels.com/photos/279746/pexels-photo-279746.jpeg",
                    Features: [
                        { Feature: "Ücretsiz WiFi" },
                        { Feature: "Klima" },
                        { Feature: "Minibar" }
                    ]
                },
                {
                    Type: "Deluxe Süit",
                    Capacity: 4,
                    Price: 2000,
                    Image: "https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg",
                    Features: [
                        { Feature: "Ücretsiz WiFi" },
                        { Feature: "Jakuzi" },
                        { Feature: "Manzara" }
                    ]
                }
            ]
        },
        {
            HotelID: 2,
            Name: "Sea View Resort - Antalya",
            Location: "Antalya",
            Rating: 4.5,
            Price: 900,
            Image: "https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg",
            Description: "Deniz manzaralı odalarıyla Ege'nin büyüleyici maviliğine uyanacağınız huzur dolu bir tatil sizleri bekliyor. Modern ve zarif tasarımıyla dikkat çeken odalarda konfor ve doğa iç içe sunuluyor. Gün boyu süren spa olanakları, termal havuzlar ve aromaterapi masajlarıyla bedeniniz yenilenirken, ruhunuz da dinginliğe kavuşuyor. Ege mutfağının enfes tatları ve gün batımı manzaralarıyla bu tatil, hafızanızda yer edecek özel bir deneyime dönüşüyor.",
            Rooms: [
                {
                    Type: "Standart Deniz Manzaralı",
                    Capacity: 2,
                    Price: 1500,
                    Image: "https://images.pexels.com/photos/271617/pexels-photo-271617.jpeg",
                    Features: [
                        { Feature: "Ücretsiz WiFi" },
                        { Feature: "Balkon" }
                    ]
                }
            ]
        },
        {
            HotelID: 5,
            Name: "Luxor Spa & Resort - Bodrum",
            Location: "Bodrum",
            Rating: 4.7,
            Price: 1400,
            Image: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg",
            Description: "Ege’nin masmavi sularına karşı konumlanmış bu lüks spa oteli, doğayla iç içe huzurlu atmosferi ve modern olanaklarıyla ruhunuzu ve bedeninizi şımartıyor. Denizin esintisi eşliğinde aromaterapi masajları, termal havuzlar ve eşsiz manzaralı dinlenme alanlarıyla unutulmaz bir konaklama deneyimi sunuyor. Zeytin ağaçlarının gölgesinde başlayan günler, Ege mutfağının leziz tatlarıyla taçlanıyor.",
            Rooms: [
                {
                    Type: "Suit Odası",
                    Capacity: 2,
                    Price: 1400,
                    Image: "https://images.pexels.com/photos/271619/pexels-photo-271619.jpeg",
                    Features: [
                        { Feature: "Jakuzi" },
                        { Feature: "Özel Plaj" },
                        { Feature: "Spa Girişi" }
                    ]
                }
            ]
        },
];

// Öne çıkan otelleri yükle
function loadFeaturedHotels() {
    const hotelsGrid = document.getElementById('hotels-grid');
    if (!hotelsGrid) return;

    if (hotels.length === 0) {
        hotelsGrid.innerHTML = '<p class="no-hotels">Gösterilecek otel bulunamadı.</p>';
        return;
    }

    // Rastgele 3 otel seç
    const featuredHotels = [...hotels]
        .sort(() => 0.5 - Math.random())
        .slice(0, 3);

    hotelsGrid.innerHTML = featuredHotels.map(hotel => `
        <div class="hotel-card" data-hotel-id="${hotel.HotelID}">
            <img src="${hotel.Image}" alt="${hotel.Name}" loading="lazy">
            <div class="hotel-info">
    <h3>${hotel.Name}</h3>
    <div class="location">
        <i class="fas fa-map-marker-alt"></i>
        ${hotel.Location}
    </div>
    <div class="rating">
        ${'★'.repeat(Math.floor(hotel.Rating))}${'☆'.repeat(5 - Math.floor(hotel.Rating))}
        <span>${hotel.Rating.toFixed(1)}</span>
    </div>
    <p class="description">${hotel.Description}</p>
    
    <!-- Özellikler Listesi -->
    <div class="features">
        <h4><i class="fas fa-star"></i> Başlıca Özellikler</h4>
        <ul>
            ${hotel.Rooms[0].Features.map(feature => `
                <li><i class="fas fa-check-circle"></i> ${feature.Feature}</li>
            `).join('')}
        </ul>
    </div>
</div>
        </div>
    `).join('');
}
document.addEventListener('DOMContentLoaded', () => {
    updateNavbar();
    setupMobileMenu();
    loadFeaturedHotels();
    
    // Klavye kısayolları
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelector('.navbar-menu').classList.remove('active');
        }
    });
});