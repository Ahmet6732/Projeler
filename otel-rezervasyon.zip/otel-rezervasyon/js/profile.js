let users = JSON.parse(localStorage.getItem('users')) || [];
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;

// `hotels` dizisini `reservation.html` ile uyumlu hale getiriyoruz
let hotels = JSON.parse(localStorage.getItem('hotels')) || [
    { id: 1, name: "Grand Palace - İstanbul", city: "İstanbul", Rating: 4.8, Image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg", Rooms: [{ Type: "Standart Oda", Price: 1200, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Klima" }, { Feature: "Minibar" }] }, { Type: "Deluxe Süit", Price: 2000, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Jakuzi" }, { Feature: "Manzara" }] }] },
    { id: 2, name: "Sea View Resort - Antalya", city: "Antalya", Rating: 4.5, Image: "https://images.pexels.com/photos/261169/pexels-photo-261169.jpeg", Rooms: [{ Type: "Standart Deniz Manzaralı", Price: 1500, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Balkon" }] }] },
    { id: 4, name: "City Comfort - Ankara", city: "Ankara", Rating: 4.0, Image: "https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg", Rooms: [{ Type: "Tek Kişilik Oda", Price: 800, Features: [{ Feature: "Ücretsiz WiFi" }, { Feature: "Çalışma Masası" }] }] },
    { id: 5, name: "Luxor Spa & Resort - Bodrum", city: "Muğla", Rating: 4.7, Image: "https://images.pexels.com/photos/338504/pexels-photo-338504.jpeg", Rooms: [{ Type: "Suit Odası", Price: 1400, Features: [{ Feature: "Özel Plaj" }, { Feature: "Jakuzi" }, { Feature: "Spa Girişi" }] }] },
    { id: 6, name: "Cappadocia Cave Hotel - Nevşehir", city: "Nevşehir", Rating: 4.9, Image: "https://images.pexels.com/photos/261395/pexels-photo-261395.jpeg", Rooms: [{ Type: "Mağara Süiti", Price: 1800, Features: [{ Feature: "Doğal Taş Duş" }, { Feature: "Şömine" }, { Feature: "Balon Turu Hediye" }] }] },
    { id: 3, name: "Pine Forest Hotel - Bursa", city: "Bursa", Rating: 4.3, Image: "https://images.pexels.com/photos/2581922/pexels-photo-2581922.jpeg", Rooms: [{ Type: "Orman Manzaralı Oda", Price: 850, Features: [{ Feature: "Şömine" }, { Feature: "Doğa Yürüyüş Parkuru" }] }] },
    { id: 9, name: "Business Tower - İzmir", city: "İzmir", Rating: 4.5, Image: "https://images.pexels.com/photos/323780/pexels-photo-323780.jpeg", Rooms: [{ Type: "Executive Oda", Price: 1400, Features: [{ Feature: "Çalışma Masası" }, { Feature: "Toplantı Odası Erişimi" }] }] },
    { id: 7, name: "Thermal Palace - Afyon", city: "Afyon", Rating: 4.4, Image: "https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg", Rooms: [{ Type: "Termal Suit", Price: 950, Features: [{ Feature: "Özel Termal Küvet" }, { Feature: "Spa Paketi" }] }] },
    { id: 8, name: "Ski Lodge - Kayseri", city: "Kayseri", Rating: 4.6, Image: "https://images.pexels.com/photos/1365425/pexels-photo-1365425.jpeg", Rooms: [{ Type: "Kayakçı Odası", Price: 1300, Features: [{ Feature: "Kayak Dolabı" }, { Feature: "Şömine" }, { Feature: "Kayak Liftine Yakın" }] }] }
];

function saveToLocalStorage() {
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    localStorage.setItem('hotels', JSON.stringify(hotels));
}

function updateNavbar() {
    const loginLink = document.querySelector('.navbar-menu .login-btn');
    if (!loginLink) return;

    if (currentUser) {
        loginLink.innerHTML = '<i class="fas fa-sign-out-alt"></i> Çıkış Yap';
        loginLink.href = '#';
        loginLink.onclick = handleLogout;
    } else {
        loginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i> Giriş Yap';
        loginLink.href = 'login.html';
        loginLink.onclick = null;
    }
}

function handleLogout(e) {
    e.preventDefault();
    currentUser = null;
    saveToLocalStorage();
    showToast('Çıkış yapıldı!', 'success');
    setTimeout(() => window.location.href = 'index.html', 1500);
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 3000);
    }, 100);
}

function calculateNights(checkIn, checkOut) {
    const start = new Date(checkIn);
    const end = new Date(checkOut);
    const diffTime = Math.abs(end - start);
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

function getRandomHotelImage() {
    const images = [
        'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg',
        'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg',
        'https://images.pexels.com/photos/271618/pexels-photo-271618.jpeg'
    ];
    return images[Math.floor(Math.random() * images.length)];
}

function updateUserInUsersArray() {
    const userIndex = users.findIndex(u => u.username === currentUser.username);
    if (userIndex !== -1) {
        users[userIndex] = currentUser;
    }
}

function loadReservations() {
    const reservationsList = document.getElementById('reservations-list');
    if (!reservationsList) {
        console.error('reservations-list element not found');
        return;
    }

    reservationsList.innerHTML = '<h3 class="header-title">Tüm Rezervasyonlar</h3>';
    if (!currentUser?.reservations || currentUser.reservations.length === 0) {
        reservationsList.innerHTML += '<div class="no-reservations">Henüz rezervasyonunuz yok.</div>';
        return;
    }

    // Display reservations without images
    currentUser.reservations.forEach(res => {
        const resItem = document.createElement('div');
        resItem.className = 'reservation-item';

        // Find the hotel data with strict matching
        const hotel = hotels.find(h => h.id === res.hotelId);
        if (!hotel) {
            console.warn(`Hotel with ID ${res.hotelId} not found in hotels list. Using fallback name: ${res.hotelName || "Bilinmeyen Otel"}`, res);
        }

        // Use hotel name if found, otherwise fallback to reservation's hotelName or default
        const hotelName = hotel ? hotel.name : (res.hotelName || "Bilinmeyen Otel");

        // Determine status
        const today = new Date();
        const checkOutDate = new Date(res.checkOut);
        const isPast = checkOutDate < today;
        const statusClass = isPast ? 'cancelled' : (res.status === 'confirmed' ? 'confirmed' : 'cancelled');
        const statusText = isPast ? 'Geçmiş' : (res.status === 'confirmed' ? 'Onaylandı' : 'İptal Edildi');

        resItem.innerHTML = `
            <div class="reservation-card">
                <div class="reservation-details">
                    <div class="hotel-name-overlay">
                        <h3 class="hotel-name">${hotelName}</h3>
                        <div class="reservation-meta">
                            <span class="status-badge ${statusClass}">${statusText}</span>
                            <span class="reservation-id">#${res.id.slice(-6)}</span>
                        </div>
                    </div>
                    <div class="detail-row">
                        <i class="fas fa-bed detail-icon"></i>
                        <span>${res.roomType || 'Belirtilmemiş'}</span>
                    </div>
                    <div class="detail-row">
                        <i class="fas fa-calendar-alt detail-icon"></i>
                        <span>${formatDate(res.checkIn)} - ${formatDate(res.checkOut)}</span>
                        <span class="nights-badge">${res.nights || calculateNights(res.checkIn, res.checkOut)} Gece</span>
                    </div>
                    <div class="detail-row">
                        <i class="fas fa-user detail-icon"></i>
                        <span>${res.guestInfo?.fullName || 'Bilinmeyen Misafir'}</span>
                    </div>
                    <div class="price-row">
                        <i class="fas fa-tag detail-icon"></i>
                        <span>Toplam</span>
                        <span class="price">${res.totalPrice || '0'} TL</span>
                    </div>
                    ${!isPast && res.status === 'confirmed' ? `
                        <button class="cancel-btn" onclick="cancelReservation('${res.id}')">
                            <i class="fas fa-times"></i> Rezervasyonu İptal Et
                        </button>
                    ` : ''}
                </div>
            </div>
        `;

        reservationsList.appendChild(resItem);
    });
}

// Rezervasyon iptal fonksiyonu
function cancelReservation(reservationId) {
    if (!currentUser || !currentUser.reservations) return;

    const reservationIndex = currentUser.reservations.findIndex(res => res.id === reservationId);
    if (reservationIndex !== -1) {
        currentUser.reservations[reservationIndex].status = 'cancelled';
        updateUserInUsersArray();
        saveToLocalStorage();
        showToast('Rezervasyon iptal edildi!', 'success');
        loadReservations(); // Listeyi güncelle
    }
}

function formatDate(dateString) {
    if (!dateString) return 'Bilinmiyor';
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
}

console.log('Reservations loaded:', currentUser.reservations);
function loadReviews() {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) return;

    // Eğer hiç yorum yoksa, başlık ve listeyi göstermeyelim
    if (!currentUser.reviews || currentUser.reviews.length === 0) {
        reviewsList.innerHTML = `
            <style>
                .no-reviews {
                    color: #ffffff;
                    background: linear-gradient(135deg, #34495e, #2980b9);
                    padding: 8px 16px;
                    border-radius: 15px;
                    text-align: center;
                    margin: 15px 0;
                    font-size: 1.1em;
                    font-style: italic;
                    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                    transition: transform 0.3s ease, box-shadow 0.3s ease;
                }

                .no-reviews:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
                }
            </style>
            <div class="no-reviews">Henüz yorumunuz yok.</div>
        `;
        return;
    }

    // Eğer yorum varsa başlığı ve yorumları ekle
    reviewsList.innerHTML = `
        <style>
            .reviews-header {
                color: #ffffff;
                background: linear-gradient(135deg, #34495e, #2980b9);
                padding: 10px 16px;
                border-radius: 15px;
                text-align: center;
                margin: 15px 0;
                font-size: 1.3em;
                font-style: italic;
                box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
                transition: transform 0.3s ease, box-shadow 0.3s ease;
            }

            .reviews-header:hover {
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3);
            }
        </style>
        <div class="reviews-header">
            <i class="fas fa-star"></i> Yorumlarım
        </div>
    `;

    currentUser.reviews.forEach(review => {
        const reviewItem = document.createElement('div');
        reviewItem.className = 'review-item';
        
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += i <= review.rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
        }
        
        reviewItem.innerHTML = `
            <h4>${review.hotel}</h4>
            <div class="review-rating">${stars}</div>
            <p class="review-text">${review.text}</p>
            <p class="review-date"><strong>Tarih:</strong> ${review.date}</p>
        `;
        reviewsList.appendChild(reviewItem);
    });
}



function setupTabs() {
    const urlParams = new URLSearchParams(window.location.search);
    const activeTab = urlParams.get('tab') || 'reservations';

    document.querySelectorAll('.tab-btn').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
            window.history.pushState({}, '', `?tab=${tabId}`);
        });

        const tabId = button.getAttribute('data-tab');
        if (tabId === activeTab) {
            button.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        }
    });
}

function populateHotelDropdown() {
    const hotelSelect = document.getElementById('review-hotel');
    if (!hotelSelect) {
        console.error('Hotel dropdown element with id "review-hotel" not found.');
        return;
    }

    while (hotelSelect.options.length > 0) {
        hotelSelect.remove(0);
    }

    const defaultOption = document.createElement('option');
    defaultOption.value = '';
    defaultOption.textContent = 'Otel Seçiniz';
    hotelSelect.appendChild(defaultOption);

    hotels.forEach(hotel => {
        const option = document.createElement('option');
        option.value = hotel.id;
        option.textContent = `${hotel.name} (${hotel.city})`;
        hotelSelect.appendChild(option);
    });
}

function setupStarRating() {
    const stars = document.querySelectorAll('.star-rating i');
    if (!stars.length) return;

    stars.forEach(star => {
        star.addEventListener('click', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            document.getElementById('review-rating').value = rating;

            stars.forEach(s => {
                s.classList.remove('fas');
                s.classList.add('far');
            });

            for (let i = 0; i < rating; i++) {
                stars[i].classList.remove('far');
                stars[i].classList.add('fas');
            }
        });
    });
}

function setupProfilePage() {
    if (!currentUser) {
        showToast('Lütfen giriş yapın!', 'error');
        setTimeout(() => window.location.replace('login.html'), 1500);
        return;
    }

    if (!currentUser.reservations) currentUser.reservations = [];
    if (!currentUser.reviews) currentUser.reviews = [];

    document.getElementById('username-display').textContent = currentUser.username || 'Kullanıcı';
    document.getElementById('member-since-date').textContent = currentUser.registrationDate || new Date().toLocaleDateString('tr-TR');

    loadReservations();
    loadReviews();
    setupTabs();
    populateHotelDropdown(); 
    setupStarRating();

    document.getElementById('add-review-form')?.addEventListener('submit', function (e) {
    e.preventDefault();

    const hotelId = parseInt(document.getElementById('review-hotel').value);
    const rating = parseInt(document.getElementById('review-rating').value);
    const text = document.getElementById('review-text').value.trim();

    if (!hotelId || !rating || !text) {
        showToast("Lütfen tüm alanları doldurun.", "error");
        return;
    }

    const hotel = hotels.find(h => h.id === hotelId);
    const review = {
        hotelId,
        hotel: hotel?.name || "Bilinmeyen Otel",
        rating,
        text,
        date: new Date().toLocaleDateString('tr-TR')
    };

    currentUser.reviews.push(review);
    updateUserInUsersArray();
    saveToLocalStorage();

    showToast("Yorumunuz başarıyla eklendi!", "success");

    // Formu temizle
    document.getElementById('review-hotel').value = '';
    document.getElementById('review-rating').value = 0;
    document.getElementById('review-text').value = '';

    // Yıldızları sıfırla
    document.querySelectorAll('.star-rating i').forEach(s => {
        s.classList.remove('fas');
        s.classList.add('far');
    });

    // Yorumları yeniden yükle
    loadReviews();
});

}

document.addEventListener('DOMContentLoaded', function() {
    updateNavbar();
    setupProfilePage();
});