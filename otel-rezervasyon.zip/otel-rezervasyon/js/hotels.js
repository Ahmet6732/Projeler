// hotels.js - JavaScript for hotels.html

// Shared data initialization
let currentUser = JSON.parse(localStorage.getItem('currentUser')) || null;
const HOTELS_PER_PAGE = 6;
let currentPage = 1;
let allHotels = [];
let filteredHotels = [];

// Shared functions
function updateNavbar() {
    const loginLink = document.querySelector('.navbar-menu .login-btn');
    if (!loginLink) return;

    if (currentUser) {
        loginLink.innerHTML = '<i class="fas fa-sign-out-alt"></i> Çıkış Yap';
        loginLink.href = '#';
        loginLink.onclick = handleLogout;
    } else {
        loginLink.innerHTML = '<i class="fas fa-sign-in-alt"></i> Giriş Yap';
        loginLink.href = 'login.html';
        loginLink.onclick = null;
    }
}

function handleLogout(e) {
    e.preventDefault();
    currentUser = null;
    localStorage.removeItem('currentUser');
    updateNavbar();
    showToast('Başarıyla çıkış yapıldı', 'success');
    setTimeout(() => window.location.href = 'index.html', 1500);
}

// Toast notification system
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }, 100);
}

// Hotels page specific functions
async function fetchHotels() {
    try {
        const response = await fetch('http://localhost:3000/api/hotels');
        if (!response.ok) {
            throw new Error(`Failed to fetch hotels: ${response.status} ${response.statusText}`);
        }
        allHotels = await response.json();
        console.log('Fetched hotels:', allHotels); // Veriyi konsola yazdır
        return allHotels;
    } catch (error) {
        console.error('Error fetching hotels:', error);
        showToast('Otel bilgileri yüklenirken bir hata oluştu', 'error');
        const container = document.querySelector('.hotel-grid');
        if (container) {
            container.innerHTML = `
                <div class="no-results">
                    <i class="fas fa-hotel"></i>
                    <h3>Otel bilgileri yüklenemedi</h3>
                    <p>Bağlantınızı kontrol edin veya daha sonra tekrar deneyin.</p>
                </div>
            `;
        }
        return [];
    }
}

function filterHotels() {
    const urlParams = new URLSearchParams(window.location.search);
    const city = urlParams.get('city');
    const type = urlParams.get('type');
    const minPrice = parseInt(urlParams.get('minPrice')) || 0;
    const maxPrice = parseInt(urlParams.get('maxPrice')) || Infinity;
    const searchQuery = urlParams.get('search') || '';
    
    filteredHotels = allHotels.filter(hotel => {
        const matchesCity = !city || hotel.Location.toLowerCase() === city.toLowerCase();
        const matchesType = !type || hotel.Type === type; // Backend'den gelen alan adlarına göre güncellendi
        const matchesPrice = hotel.Price >= minPrice && hotel.Price <= maxPrice;
        const matchesSearch = searchQuery === '' || 
            hotel.Name.toLowerCase().includes(searchQuery.toLowerCase()) || 
            hotel.Location.toLowerCase().includes(searchQuery.toLowerCase());
        
        return matchesCity && matchesType && matchesPrice && matchesSearch;
    });
    
    currentPage = 1; // Reset to first page when filters change
    renderHotels();
    renderPagination();
}

function renderHotels() {
    const container = document.querySelector('.hotel-grid');
    const checkinInput = document.getElementById('checkin');
    const checkoutInput = document.getElementById('checkout');
    if (!container) {
        console.error('Hotel grid container not found');
        return;
    }
    
    const startIdx = (currentPage - 1) * HOTELS_PER_PAGE;
    const paginatedHotels = filteredHotels.slice(startIdx, startIdx + HOTELS_PER_PAGE);
    
    if (paginatedHotels.length === 0) {
        container.innerHTML = `
            <div class="no-results">
                <i class="fas fa-hotel"></i>
                <h3>Aradığınız kriterlere uygun otel bulunamadı</h3>
                <p>Filtrelerinizi değiştirmeyi deneyebilirsiniz.</p>
                <button onclick="window.location.href='hotels.html'">Filtreleri Temizle</button>
            </div>
        `;
        return;
    }
    
    container.innerHTML = paginatedHotels.map(hotel => `
        <div class="hotel-card">
            <div class="hotel-image">
                <img src="${hotel.Image}" alt="${hotel.Name}">
            </div>
            <div class="hotel-info">
                <h3 class="hotel-name">${hotel.Name}</h3>
                <div class="hotel-location">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>${hotel.Location}</span>
                </div>
                <div class="hotel-rating">
                    <span class="stars">${'★'.repeat(Math.floor(hotel.Rating))}${'☆'.repeat(5 - Math.floor(hotel.Rating))}</span>
                    <span class="rating-value">${hotel.Rating}</span>
                </div>
                <p>${hotel.Description}</p>
                <div class="hotel-price">
                    <div class="price">${hotel.Price} TL <small>gecelik</small></div>
                    <button class="details-btn" data-hotel-id="${hotel.HotelID}">Detayları Gör</button>
                </div>
            </div>
            <div class="hotel-details" id="hotel-details-${hotel.HotelID}">
                <h3>Otel Galerisi</h3>
                <div class="hotel-gallery">
                    ${hotel.Images.map(img => `<img src="${img.ImageURL}" alt="${hotel.Name}">`).join('')}
                </div>
                <div class="room-types">
                    <h3>Oda Tipleri</h3>
                    ${hotel.Rooms.map(room => `
                        <div class="room-type">
                            <div class="room-info">
                                <h4>${room.Type} (${room.Capacity} Kişi)</h4>
                                <ul class="room-features">
                                    ${room.Features.map(feature => `<li><i class="fas fa-check"></i> ${feature}</li>`).join('')}
                                </ul>
                            </div>
                            <div class="room-price">
                                <div class="price">${room.Price} TL</div>
                                <div class="per-night">gecelik</div>
                                <button class="book-btn" data-hotel-id="${hotel.HotelID}" data-room-type="${encodeURIComponent(room.Type)}">Rezervasyon Yap</button>
                            </div>
                            <img src="${room.Image}" alt="${room.Type}" style="width:100%; margin-top:10px;">
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `).join('');
    
    // Detay butonlarına event listener ekle
    document.querySelectorAll('.details-btn').forEach(button => {
        button.addEventListener('click', function() {
            const hotelId = this.getAttribute('data-hotel-id');
            const detailsSection = document.getElementById(`hotel-details-${hotelId}`);
            
            // Tüm detay bölümlerini kapat
            document.querySelectorAll('.hotel-details').forEach(section => {
                if (section.id !== `hotel-details-${hotelId}`) {
                    section.classList.remove('active');
                    const btn = section.closest('.hotel-card').querySelector('.details-btn');
                    if (btn) btn.textContent = 'Detayları Gör';
                }
            });
            
            // İlgili detay bölümünü aç/kapat
            detailsSection.classList.toggle('active');
            
            // Buton metnini değiştir
            if (detailsSection.classList.contains('active')) {
                this.textContent = 'Detayları Gizle';
            } else {
                this.textContent = 'Detayları Gör';
            }
        });
    });
    
    // Rezervasyon butonlarına event listener ekle
    document.querySelectorAll('.book-btn').forEach(button => {
        button.addEventListener('click', function() {
            const hotelId = this.getAttribute('data-hotel-id');
            const roomType = this.getAttribute('data-room-type');
            const checkin = checkinInput.value;
            const checkout = checkoutInput.value;

            if (!checkin || !checkout) {
                showToast('Lütfen giriş ve çıkış tarihlerini seçiniz!', 'error');
                return;
            }
            if (new Date(checkout) <= new Date(checkin)) {
                showToast('Çıkış tarihi giriş tarihinden sonra olmalı!', 'error');
                return;
            }

            window.location.href = `reservation.html?hotel=${hotelId}&room=${roomType}&checkin=${checkin}&checkout=${checkout}`;
        });
    });
}

function renderPagination() {
    const pagination = document.querySelector('.pagination');
    if (!pagination) return;
    
    const totalPages = Math.ceil(filteredHotels.length / HOTELS_PER_PAGE);
    
    if (totalPages <= 1) {
        pagination.style.display = 'none';
        return;
    }
    
    pagination.style.display = 'flex';
    let html = `
        <button ${currentPage === 1 ? 'disabled' : ''} onclick="changePage(${currentPage - 1})">
            Önceki
        </button>
    `;
    
    for (let i = 1; i <= totalPages; i++) {
        html += `
            <button ${i === currentPage ? 'class="active"' : ''} onclick="changePage(${i})">
                ${i}
            </button>
        `;
    }
    
    html += `
        <button ${currentPage === totalPages ? 'disabled' : ''} onclick="changePage(${currentPage + 1})">
            Sonraki
        </button>
    `;
    
    pagination.innerHTML = html;
}

function changePage(page) {
    if (page < 1 || page > Math.ceil(filteredHotels.length / HOTELS_PER_PAGE)) return;
    currentPage = page;
    renderHotels();
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function initSearchForm() {
    const searchForm = document.querySelector('.search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const location = document.getElementById('location').value;
            const checkin = document.getElementById('checkin').value;
            const checkout = document.getElementById('checkout').value;
            const guests = document.getElementById('guests').value;
            
            if (!checkin || !checkout) {
                showToast('Lütfen giriş ve çıkış tarihlerini seçiniz!', 'error');
                return;
            }
            if (new Date(checkout) <= new Date(checkin)) {
                showToast('Çıkış tarihi giriş tarihinden sonra olmalı!', 'error');
                return;
            }

            // Update URL with search parameters
            const url = new URL(window.location.href);
            if (location) url.searchParams.set('city', location);
            if (checkin) url.searchParams.set('checkin', checkin);
            if (checkout) url.searchParams.set('checkout', checkout);
            if (guests) url.searchParams.set('guests', guests);
            
            window.location.href = url.toString();
        });
    }
}

function initSorting() {
    const sortSelect = document.getElementById('sort');
    if (sortSelect) {
        sortSelect.addEventListener('change', function() {
            switch(this.value) {
                case 'price-low':
                    filteredHotels.sort((a, b) => a.Price - b.Price);
                    break;
                case 'price-high':
                    filteredHotels.sort((a, b) => b.Price - a.Price);
                    break;
                case 'rating':
                    filteredHotels.sort((a, b) => b.Rating - a.Rating);
                    break;
                default: // 'popular'
                    filteredHotels.sort((a, b) => b.Rating - a.Rating); // Varsayılan sıralama
            }
            
            currentPage = 1;
            renderHotels();
            renderPagination();
        });
    }
}

// Initialize hotels page
document.addEventListener('DOMContentLoaded', async function() {
    updateNavbar();
    initSearchForm();
    initSorting();
    
    // Load hotels and then filter them based on URL parameters
    await fetchHotels();
    filterHotels();
    
    // Make these functions available globally
    window.changePage = changePage;
});

// Mobile menu toggle
document.querySelector('.mobile-menu-btn')?.addEventListener('click', function() {
    document.querySelector('.navbar-menu')?.classList.toggle('active');
    this.classList.toggle('active');
});