const hotels = [
    { id: 1, name: "Grand Palace - İstanbul", city: "İstanbul", Rooms: [{ Type: "Standart Oda", Price: 1200 }, { Type: "Deluxe Süit", Price: 2000 }] },
    { id: 2, name: "Sea View Resort - Antalya", city: "Antalya", Rooms: [{ Type: "Standart Deniz Manzaralı", Price: 1500 }] },
    { id: 4, name: "City Comfort - Ankara", city: "Ankara", Rooms: [{ Type: "Tek Kişilik Oda", Price: 800 }] },
    { id: 5, name: "Luxor Spa & Resort - Bodrum", city: "Muğla", Rooms: [{ Type: "Suit Odası", Price: 1400 }] },
    { id: 6, name: "Cappadocia Cave Hotel - Nevşehir", city: "Nevşehir", Rooms: [{ Type: "Mağara Süiti", Price: 1800 }] },
    { id: 7, name: "Pine Forest Hotel - Bursa", city: "Bursa", Rooms: [{ Type: "Orman Manzaralı Oda", Price: 850 }] },
    { id: 8, name: "Business Tower - İzmir", city: "İzmir", Rooms: [{ Type: "Executive Oda", Price: 1400 }] },
    { id: 9, name: "Thermal Palace - Afyon", city: "Afyon", Rooms: [{ Type: "Termal Suit", Price: 950 }] },
    { id: 10, name: "Ski Lodge - Kayseri", city: "Kayseri", Rooms: [{ Type: "Kayakçı Odası", Price: 1300 }] }
];

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `<i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i> ${message}`;
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.classList.add('show');
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 400);
        }, 3000);
    }, 100);
}

function calculateNights(checkIn, checkOut) {
    const oneDay = 24 * 60 * 60 * 1000;
    return Math.round(Math.abs((new Date(checkOut) - new Date(checkIn)) / oneDay));
}

function formatDate(dateString) {
    if (!dateString) return 'Bilinmiyor';
    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    return new Date(dateString).toLocaleDateString('tr-TR', options);
}

function updateLocalStorage(users) {
    localStorage.setItem('users', JSON.stringify(users));
    const currentUser = JSON.parse(localStorage.getItem('currentUser'));
    if (currentUser) {
        const updatedUser = users.find(u => u.username === currentUser.username);
        if (updatedUser) {
            localStorage.setItem('currentUser', JSON.stringify(updatedUser));
        }
    }
}

function populateHotelSelect() {
    const hotelSelect = document.getElementById('edit-hotel');
    hotelSelect.innerHTML = '<option value="">Otel Seçin</option>';
    hotels.forEach(hotel => {
        const option = document.createElement('option');
        option.value = hotel.name;
        option.dataset.id = hotel.id;
        option.textContent = hotel.name;
        hotelSelect.appendChild(option);
    });
}

function populateRoomTypeSelect(hotelName) {
    const roomTypeSelect = document.getElementById('edit-room-type');
    roomTypeSelect.innerHTML = '<option value="">Oda Tipi Seçin</option>';
    const hotel = hotels.find(h => h.name === hotelName);
    if (hotel) {
        hotel.Rooms.forEach(room => {
            const option = document.createElement('option');
            option.value = room.Type;
            option.textContent = room.Type;
            roomTypeSelect.appendChild(option);
        });
    }
}

function loadAllReservations() {
    const reservationsList = document.getElementById('reservations-list');
    if (!reservationsList) {
        console.error('reservations-list element not found');
        showToast('Sayfa yüklenirken hata oluştu!', 'error');
        return;
    }

    reservationsList.innerHTML = '';
    const users = JSON.parse(localStorage.getItem('users')) || [];
    let allReservations = [];

    users.forEach(user => {
        if (user.reservations && user.reservations.length > 0) {
            user.reservations.forEach(res => {
                allReservations.push({
                    ...res,
                    username: user.username
                });
            });
        }
    });

    if (allReservations.length === 0) {
        reservationsList.innerHTML += '<p class="no-reservations">Henüz rezervasyon bulunmamaktadır.</p>';
        return;
    }

    allReservations.forEach(res => {
        let hotel = hotels.find(h => h.id === res.hotelId);
        if (!hotel && res.hotel) {
            hotel = hotels.find(h => h.name === res.hotel) || { name: res.hotel || "Bilinmeyen Otel" };
        }
        if (!hotel) {
            hotel = { name: "Bilinmeyen Otel" };
        }

        const resItem = document.createElement('div');
        resItem.className = 'reservation-item';
        resItem.innerHTML = `
            <div class="reservation-card">
                <div class="reservation-content">
                    <h3 class="hotel-name">${hotel.name}</h3>
                    <div class="reservation-meta">
                        <span class="status-badge confirmed">Onaylandı</span>
                        <span class="reservation-id">#${res.id.slice(-6)}</span>
                    </div>
                    <div class="reservation-details">
                        <div class="detail-item">
                            <i class="fas fa-user"></i>
                            <span>Kullanıcı: ${res.username}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-bed"></i>
                            <span>${res.roomType}</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-calendar-alt"></i>
                            <span>${formatDate(res.checkIn)} - ${formatDate(res.checkOut)}</span>
                            <span class="nights">${res.nights} Gece</span>
                        </div>
                        <div class="detail-item">
                            <i class="fas fa-user"></i>
                            <span>${res.guestInfo.fullName}</span>
                        </div>
                        <div class="detail-item price">
                            <i class="fas fa-tag"></i>
                            <span>${res.totalPrice} TL</span>
                        </div>
                        ${res.notes ? `
                        <div class="detail-item">
                            <i class="fas fa-sticky-note"></i>
                            <span>Özel İstekler: ${res.notes}</span>
                        </div>` : ''}
                        <div class="reservation-actions">
                            <button class="edit-btn" data-res-id="${res.id}" data-username="${res.username}"><i class="fas fa-edit"></i> Düzenle</button>
                            <button class="cancel-btn" data-res-id="${res.id}" data-username="${res.username}"><i class="fas fa-trash"></i> İptal</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        reservationsList.appendChild(resItem);
    });
    console.log('All reservations loaded:', allReservations);
}

function loadAllReviews() {
    const reviewsList = document.getElementById('reviews-list');
    if (!reviewsList) {
        console.error('reviews-list element not found');
        showToast('Sayfa yüklenirken hata oluştu!', 'error');
        return;
    }

    reviewsList.innerHTML = `
        <div class="review-header">💬 Tüm Yorumlar</div>
    `;
    const users = JSON.parse(localStorage.getItem('users')) || [];
    let allReviews = [];

    users.forEach(user => {
        if (user.reviews && user.reviews.length > 0) {
            user.reviews.forEach(review => {
                allReviews.push({
                    ...review,
                    username: user.username
                });
            });
        }
    });

    if (allReviews.length === 0) {
        reviewsList.innerHTML += '<p>Henüz yorum bulunmamaktadır.</p>';
        return;
    }

    allReviews.forEach(review => {
        const reviewItem = document.createElement('div');
        reviewItem.className = 'review-item';
        let stars = '';
        for (let i = 1; i <= 5; i++) {
            stars += i <= review.rating ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>';
        }
        reviewItem.innerHTML = `
            <div class="review-card">
                <h4>${review.hotel}</h4>
                <p><strong>Kullanıcı:</strong> ${review.username}</p>
                <div class="review-rating">${stars}</div>
                <p class="review-text">${review.text}</p>
                <p class="review-date"><strong>Tarih:</strong> ${review.date}</p>
                <div class="review-actions">
                    <button class="delete-review-btn" data-review-id="${review.id}" data-username="${review.username}"><i class="fas fa-trash"></i> Sil</button>
                </div>
            </div>
        `;
        reviewsList.appendChild(reviewItem);
    });
    console.log('All reviews loaded:', allReviews);
}

function setupTabs() {
    const urlParams = new URLSearchParams(window.location.search);
    const activeTab = urlParams.get('tab') || 'reservations';

    document.querySelectorAll('.tab-btn').forEach(button => {
        button.addEventListener('click', function() {
            document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
            window.history.pushState({}, '', `?tab=${tabId}`);
        });

        const tabId = button.getAttribute('data-tab');
        if (tabId === activeTab) {
            button.classList.add('active');
            document.getElementById(tabId).classList.add('active');
        }
    });
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('adminpanel.js loaded');
    loadAllReservations();
    loadAllReviews();
    setupTabs();
    populateHotelSelect();

    document.getElementById('edit-hotel').addEventListener('change', function() {
        populateRoomTypeSelect(this.value);
    });

    document.getElementById('reservations-list').addEventListener('click', function(e) {
        const btn = e.target.closest('.edit-btn') || e.target.closest('.cancel-btn');
        if (!btn) return;

        const resId = btn.dataset.resId;
        const username = btn.dataset.username;

        if (btn.classList.contains('edit-btn')) {
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find(u => u.username === username);
            const reservation = user.reservations.find(r => r.id === resId);

            if (reservation) {
                document.getElementById('edit-reservation-id').value = resId;
                document.getElementById('edit-username').value = username;
                document.getElementById('edit-hotel').value = reservation.hotel;
                populateRoomTypeSelect(reservation.hotel);
                document.getElementById('edit-room-type').value = reservation.roomType;
                document.getElementById('edit-check-in').value = reservation.checkIn;
                document.getElementById('edit-check-out').value = reservation.checkOut;
                document.getElementById('edit-full-name').value = reservation.guestInfo.fullName;
                document.getElementById('edit-phone').value = reservation.guestInfo.phone;
                document.getElementById('edit-notes').value = reservation.notes || '';
                document.getElementById('edit-modal').style.display = 'block';
            }
        } else if (btn.classList.contains('cancel-btn')) {
            if (confirm('Bu rezervasyonu iptal etmek istediğinizden emin misiniz?')) {
                const users = JSON.parse(localStorage.getItem('users')) || [];
                const user = users.find(u => u.username === username);
                user.reservations = user.reservations.filter(r => r.id !== resId);
                updateLocalStorage(users);
                loadAllReservations();
                showToast('Rezervasyon iptal edildi!', 'success');
            }
        }
    });

    document.getElementById('reviews-list').addEventListener('click', function(e) {
        const btn = e.target.closest('.delete-review-btn');
        if (!btn) return;

        const reviewId = btn.dataset.reviewId;
        const username = btn.dataset.username;

        if (confirm('Bu yorumu silmek istediğinizden emin misiniz?')) {
            const users = JSON.parse(localStorage.getItem('users')) || [];
            const user = users.find(u => u.username === username);
            if (user && user.reviews) {
                user.reviews = user.reviews.filter(r => r.id !== reviewId);
                updateLocalStorage(users);
                loadAllReviews();
                showToast('Yorum silindi!', 'success');
            } else {
                showToast('Yorum silinirken hata oluştu!', 'error');
            }
        }
    });

    const modal = document.getElementById('edit-modal');
    const closeBtn = document.querySelector('.close-btn');
    const editForm = document.getElementById('edit-reservation-form');

    closeBtn.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.addEventListener('click', function(e) {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    editForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const resId = document.getElementById('edit-reservation-id').value;
        const username = document.getElementById('edit-username').value;
        const hotelName = document.getElementById('edit-hotel').value;
        const roomType = document.getElementById('edit-room-type').value;
        const checkIn = document.getElementById('edit-check-in').value;
        const checkOut = document.getElementById('edit-check-out').value;
        const fullName = document.getElementById('edit-full-name').value.trim();
        const phone = document.getElementById('edit-phone').value.trim();
        const notes = document.getElementById('edit-notes').value.trim();

        if (!hotelName || !roomType || !checkIn || !checkOut || !fullName || !phone) {
            showToast('Lütfen tüm zorunlu alanları doldurun!', 'error');
            return;
        }

        const today = new Date().toISOString().split('T')[0];
        if (checkIn < today) {
            showToast('Giriş tarihi geçmişte olamaz!', 'error');
            return;
        }
        if (new Date(checkOut) <= new Date(checkIn)) {
            showToast('Çıkış tarihi giriş tarihinden sonra olmalı!', 'error');
            return;
        }
        if (!/^[a-zA-Z\s]+$/.test(fullName)) {
            showToast('Ad Soyad sadece harf ve boşluk içermeli!', 'error');
            return;
        }
        if (!/^0\d{10}$/.test(phone.replace(/\s/g, ''))) {
            showToast('Telefon numarası 0 ile başlamalı ve 11 haneli olmalı!', 'error');
            return;
        }

        const selectedHotel = hotels.find(h => h.name === hotelName);
        if (!selectedHotel) {
            showToast('Seçilen otel bulunamadı!', 'error');
            return;
        }
        const selectedRoom = selectedHotel.Rooms.find(r => r.Type === roomType);
        const nights = calculateNights(checkIn, checkOut);
        const roomCost = selectedRoom.Price * nights;
        const tax = roomCost * 0.1;
        const totalPrice = (roomCost + tax).toFixed(2);

        const users = JSON.parse(localStorage.getItem('users')) || [];
        const user = users.find(u => u.username === username);
        const reservation = user.reservations.find(r => r.id === resId);

        reservation.hotel = selectedHotel.name;
        reservation.hotelId = selectedHotel.id;
        reservation.roomType = roomType;
        reservation.checkIn = checkIn;
        reservation.checkOut = checkOut;
        reservation.nights = nights;
        reservation.totalPrice = totalPrice;
        reservation.guestInfo.fullName = fullName;
        reservation.guestInfo.phone = phone;
        reservation.notes = notes;

        updateLocalStorage(users);
        modal.style.display = 'none';
        loadAllReservations();
        showToast('Rezervasyon güncellendi!', 'success');
    });

    document.querySelector('.mobile-menu-btn').addEventListener('click', () => {
        const menu = document.querySelector('.navbar-menu');
        const icon = document.querySelector('.mobile-menu-btn i');
        const isActive = menu.classList.toggle('active');
        icon.className = isActive ? 'fas fa-times' : 'fas fa-bars';
    });

    const logoutLink = document.querySelector('.navbar-menu .login-btn');
    if (logoutLink) {
        logoutLink.addEventListener('click', function(e) {
            e.preventDefault();
            showToast('Admin çıkış yaptı!', 'success');
            setTimeout(() => window.location.href = 'admin.html', 1500);
        });
    }
});