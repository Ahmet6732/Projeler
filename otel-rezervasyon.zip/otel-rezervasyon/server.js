const express = require('express');
const sql = require('mssql');
const app = express();
require('dotenv').config();
app.use(express.json());
const dbConfig = {
    user: 'otel_user',
    password: 'StrongPassword123!',
    server: 'DESKTOP-3D6S2L',
    database: 'OtelRezervasyon',
    options: {
        encrypt: false, 
        trustServerCertificate: true
    }
};
let poolPromise;
async function initializeDatabase() {
    try {
        poolPromise = new sql.ConnectionPool(dbConfig)
            .connect()
            .then(pool => {
                console.log('✅ SQL Server\'a Windows Authentication ile bağlanıldı.');
                return pool;
            });
        return poolPromise;
    } catch (err) {
        console.error('❌ Veritabanı bağlantı hatası:', err);
        throw err;
    }
}
initializeDatabase().catch(err => {
    console.error('❌ Veritabanı başlatma hatası:', err);
    process.exit(1);
});
app.get('/api/hotels', async (req, res) => {
    try {
        const pool = await poolPromise;
        const hotelsResult = await pool.request().query('SELECT * FROM Hotels');
        const hotels = hotelsResult.recordset;
        for (let hotel of hotels) {
            const imagesResult = await pool.request()
                .input('HotelID', sql.Int, hotel.HotelID)
                .query('SELECT ImageURL FROM HotelImages WHERE HotelID = @HotelID');
            hotel.Images = imagesResult.recordset.map(img => ({ ImageURL: img.ImageURL }));
         const roomsResult = await pool.request()
                .input('HotelID', sql.Int, hotel.HotelID)
                .query('SELECT RoomID, Type, Capacity, Price, Image FROM Rooms WHERE HotelID = @HotelID');
            hotel.Rooms = roomsResult.recordset;
            for (let room of hotel.Rooms) {
                const featuresResult = await pool.request()
                    .input('RoomID', sql.Int, room.RoomID)
                    .query('SELECT Feature FROM RoomFeatures WHERE RoomID = @RoomID');
                room.Features = featuresResult.recordset.map(f => ({ Feature: f.Feature }));
            }
        }
        res.json(hotels);
    } catch (err) {
        console.error('Error fetching hotels:', err);
        res.status(500).json({ error: 'Failed to fetch hotels', details: err.message });
    }
});
app.post('/api/reservations', async (req, res) => {
    try {
        const pool = await poolPromise;
        const {
            hotelId, userId, roomType, checkIn, checkOut, nights, totalPrice,
            fullName, email, phone, notes, paymentMethod
        } = req.body;

        if (!hotelId || !userId || !roomType || !checkIn || !checkOut || !nights || !totalPrice || !fullName || !email || !phone || !paymentMethod) {
            return res.status(400).json({ error: 'Missing or invalid data' });
        }
        const result = await pool.request()
            .input('HotelID', sql.Int, hotelId)
            .input('UserID', sql.Int, userId)
            .input('RoomType', sql.NVarChar, roomType)
            .input('CheckIn', sql.Date, checkIn)
            .input('CheckOut', sql.Date, checkOut)
            .input('Nights', sql.Int, nights)
            .input('TotalPrice', sql.Decimal(10, 2), totalPrice)
            .input('FullName', sql.NVarChar, fullName)
            .input('Email', sql.NVarChar, email)
            .input('Phone', sql.NVarChar, phone)
            .input('Notes', sql.NVarChar, notes || '')
            .input('PaymentMethod', sql.NVarChar, paymentMethod)
            .input('Status', sql.NVarChar, 'confirmed')
            .query(`
                INSERT INTO Reservations (
                    HotelID, UserID, RoomType, CheckIn, CheckOut, Nights, TotalPrice,
                    FullName, Email, Phone, Notes, PaymentMethod, Status
                )
                OUTPUT INSERTED.ReservationID
                VALUES (
                    @HotelID, @UserID, @RoomType, @CheckIn, @CheckOut, @Nights, @TotalPrice,
                    @FullName, @Email, @Phone, @Notes, @PaymentMethod, @Status
                )
            `);
        res.json({ reservationId: result.recordset[0].ReservationID });
    } catch (err) {
        console.error('Error creating reservation:', err);
        res.status(500).json({ error: 'Failed to create reservation', details: err.message });
    }
});
app.get('/api/reservations/:userId', async (req, res) => {
    try {
        const pool = await poolPromise;
        const userId = req.params.userId;
        const result = await pool.request()
            .input('UserID', sql.Int, userId)
            .query(`
                SELECT r.*, h.Name AS HotelName, h.Image AS HotelImage
                FROM Reservations r
                JOIN Hotels h ON r.HotelID = h.HotelID
                WHERE r.UserID = @UserID
            `);
        res.json(result.recordset);
    } catch (err) {
        console.error('Error fetching reservations:', err);
        res.status(500).json({ error: 'Failed to fetch reservations', details: err.message });
    }
});
app.post('/api/reservations/:id/cancel', async (req, res) => {
    try {
        const pool = await poolPromise;
        const reservationId = req.params.id;
        const result = await pool.request()
            .input('ReservationID', sql.Int, reservationId)
            .query(`
                UPDATE Reservations
                SET Status = 'cancelled'
                WHERE ReservationID = @ReservationID AND Status = 'confirmed'
            `);
        if (result.rowsAffected[0] === 0) {
            return res.status(404).json({ error: 'Reservation not found or already cancelled' });
        }
        res.json({ message: 'Reservation cancelled' });
    } catch (err) {
        console.error('Error cancelling reservation:', err);
        res.status(500).json({ error: 'Failed to cancel reservation', details: err.message });
    }
});
app.get('/api/profiles/:username', async (req, res) => {
    try {
        const pool = await poolPromise;
        const username = req.params.username;
        const result = await pool.request()
            .input('Username', sql.NVarChar, username)
            .query('SELECT * FROM Profiles WHERE Username = @Username');
        
        if (result.recordset.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }
        res.json(result.recordset[0]);
    } catch (err) {
        console.error('Error fetching profile:', err);
        res.status(500).json({ error: 'Failed to fetch profile', details: err.message });
    }
});
app.post('/api/reviews', async (req, res) => {
    try {
        const pool = await poolPromise;
        const { hotelId, userId, rating, comment } = req.body;

        if (!hotelId || !userId || !rating) {
            return res.status(400).json({ error: 'Missing or invalid data' });
        }
        const result = await pool.request()
            .input('HotelID', sql.Int, hotelId)
            .input('UserID', sql.Int, userId)
            .input('Rating', sql.Decimal(3, 1), rating)
            .input('Comment', sql.NVarChar, comment || '')
            .query(`
                INSERT INTO Reviews (HotelID, UserID, Rating, Comment)
                OUTPUT INSERTED.ReviewID
                VALUES (@HotelID, @UserID, @Rating, @Comment)
            `);
        res.json({ reviewId: result.recordset[0].ReviewID });
    } catch (err) {
        console.error('Error adding review:', err);
        res.status(500).json({ error: 'Failed to add review', details: err.message });
    }
});
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🌐 Server running on port ${PORT}`);
});
